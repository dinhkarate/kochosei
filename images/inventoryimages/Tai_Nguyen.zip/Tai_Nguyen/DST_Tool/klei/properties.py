ImageProperties = {
    "inventoryimages" : {
        "width" : 64,
        "height" : 64,
    },
    "cookbook": {
        "width" : 256,
        "height" : 256,
        "prefix": "cookbook_",
    },
    "road" : {
        "border" : 4,
    }
}
